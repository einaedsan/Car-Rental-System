#include "SystemConfig.h"

const int SystemConfig::MAX_ACTIVE_RENTALS = 3;
const double SystemConfig::MAX_DEBT =2500;
const double SystemConfig::DAILY_LATE_FINE = 50;

int SystemDate::currentDay = 1;