#pragma once
#pragma once
#include "CarList.h"
#include "ReservationStorage.h"

void loadReservationsForCars(CarList* carList, const std::string& filename);
